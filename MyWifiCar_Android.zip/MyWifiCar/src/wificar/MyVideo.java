package wificar;

import java.io.IOException;
import java.net.Socket;
import java.net.URL;

import my.wificar.R;

import android.R.color;
import android.R.integer;
import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AbsoluteLayout;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MyVideo extends Activity
{
    private Button ForWard;
	private Button BackWard;
	private Button TurnLeft;
	private Button TurnRight;
	private Button Light;
	private Button CAM_Up;
	private Button CAM_Down;
	private Button CAM_Right;
	private Button CAM_Left;
	private Button CAM_Reset;

    URL videoUrl;
    private Thread mThreadClient = null;
	private Socket mSocketClient = null;

	public static String CameraIp;
	public static String CtrlIp;
	public static String CtrlPort;
	public static boolean Is_Scale;
    MySurfaceView r;
    
    private int Send_CMD_Status = 0;
    boolean Is_Lighted = false;
    
    private int Cam_LeftRight = 0x5A;
    private int Cam_UpDown = 0x7B;
    private int step = 2;
    private int Cam_Reset_Status = 0;

    
    
    @SuppressWarnings("deprecation")
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);//��ȥ���⣨Ӧ�õ����ֱ���Ҫд��setContentView֮ǰ����������쳣��
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        setContentView(R.layout.myvideo);
        r = (MySurfaceView)findViewById(R.id.mySurfaceViewVideo);
        
        WindowManager manager = getWindowManager();
        int Width = manager.getDefaultDisplay().getWidth();
        int Height = manager.getDefaultDisplay().getHeight();
        int btn_length = Height /8;        
        
        AbsoluteLayout.LayoutParams params;
        ForWard = (Button)findViewById(R.id.ForWard);
        params = (AbsoluteLayout.LayoutParams)ForWard.getLayoutParams();  
		params.width = btn_length;
		params.height = btn_length;
		params.x = btn_length;
		params.y = Height - btn_length*3;
		ForWard.setLayoutParams(params); 
        
        BackWard = (Button)findViewById(R.id.BackWard);
        params = (AbsoluteLayout.LayoutParams)BackWard.getLayoutParams();  
		params.width = btn_length;
		params.height = btn_length;
		params.x = btn_length;
		params.y = Height - btn_length;
		BackWard.setLayoutParams(params); 		
		
		TurnLeft = (Button)findViewById(R.id.TurnLeft);
		params = (AbsoluteLayout.LayoutParams)TurnLeft.getLayoutParams();  
		params.width = btn_length;
		params.height = btn_length;
		params.x = 0;
		params.y = Height - btn_length*2;
		TurnLeft.setLayoutParams(params); 		
		
		TurnRight = (Button)findViewById(R.id.TurnRight);
		params = (AbsoluteLayout.LayoutParams)TurnRight.getLayoutParams();  
		params.width = btn_length;
		params.height = btn_length;
		params.x = btn_length*2;
		params.y = Height - btn_length*2;
		TurnRight.setLayoutParams(params); 
		
		Light = (Button)findViewById(R.id.Light);
		params = (AbsoluteLayout.LayoutParams)Light.getLayoutParams();  
		params.width = btn_length;
		params.height = btn_length;
		params.x = btn_length;
		params.y = Height - btn_length*2;
		Light.setTextColor(Color.BLACK);
		Light.setLayoutParams(params); 
		
		CAM_Up = (Button)findViewById(R.id.Cam_Up);
        params = (AbsoluteLayout.LayoutParams)CAM_Up.getLayoutParams();  
		params.width = btn_length;
		params.height = btn_length;
		params.x = Width - btn_length*2;
		params.y = Height - btn_length;
		CAM_Up.setLayoutParams(params); 
		
		CAM_Down = (Button)findViewById(R.id.Cam_Down);
        params = (AbsoluteLayout.LayoutParams)CAM_Down.getLayoutParams();  
		params.width = btn_length;
		params.height = btn_length;
		params.x = Width - btn_length*2;
		params.y = Height - btn_length*3;
		CAM_Down.setLayoutParams(params); 
		
		CAM_Left = (Button)findViewById(R.id.Cam_Left);
        params = (AbsoluteLayout.LayoutParams)CAM_Left.getLayoutParams();  
		params.width = btn_length;
		params.height = btn_length;
		params.x = Width - btn_length*3;
		params.y = Height - btn_length*2;
		CAM_Left.setLayoutParams(params); 
		
		CAM_Right = (Button)findViewById(R.id.Cam_Right);
        params = (AbsoluteLayout.LayoutParams)CAM_Right.getLayoutParams();  
		params.width = btn_length;
		params.height = btn_length;
		params.x = Width - btn_length*1;
		params.y = Height - btn_length*2;
		CAM_Right.setLayoutParams(params); 
		
		CAM_Reset = (Button)findViewById(R.id.Cam_Reset);
        params = (AbsoluteLayout.LayoutParams)CAM_Reset.getLayoutParams();  
		params.width = btn_length;
		params.height = btn_length;
		params.x = Width - btn_length*2;
		params.y = Height - btn_length*2;
		CAM_Reset.setLayoutParams(params); 
		
		Intent intent = getIntent();
		//��Intent���и���keyȡ��value
		CameraIp = intent.getStringExtra("CameraIp");		
		//CameraIp ="http://192.168.1.1:8080/?action=snapshot";
		CtrlIp = intent.getStringExtra("CtrlIp");
		CtrlPort = intent.getStringExtra("CtrlPort");
		Is_Scale = intent.getBooleanExtra("Is_Scale", false);
		r.GetCameraIP(CameraIp);
		r.Is_Scale = Is_Scale;

	    mThreadClient = new Thread(mRunnable);
		mThreadClient.start();
		
	
		BackWard.setOnTouchListener(new View.OnTouchListener() 
		{
			public boolean onTouch(View v, MotionEvent event) 
			{
				int action = event.getAction();
				switch(action)
				{
					case MotionEvent.ACTION_DOWN:
				    	CmdBuffer[1] = (byte)0x00;
						CmdBuffer[2] = (byte)0x02;
						CmdBuffer[3] = (byte)0x00;
						Send_CMD_Status = -1;							    
				    	break;
					case MotionEvent.ACTION_UP:
						CmdBuffer[1] = (byte)0x00;
						CmdBuffer[2] = (byte)0x00;
						CmdBuffer[3] = (byte)0x00;
						Send_CMD_Status = 1;				    
						break;
					default:
						break;
				}
				return false;
			}
		});
		
		ForWard.setOnTouchListener(new View.OnTouchListener() 
		{
			public boolean onTouch(View v, MotionEvent event) 
			{
				int action = event.getAction();
				switch(action)
				{
					case MotionEvent.ACTION_DOWN:
				    	//mPrintWriterClient.print("W"); 
				    	CmdBuffer[1] = (byte)0x00;
						CmdBuffer[2] = (byte)0x01;
						CmdBuffer[3] = (byte)0x00;
						Send_CMD_Status = -1;							    
				    	break;
					case MotionEvent.ACTION_UP:
						CmdBuffer[1] = (byte)0x00;
						CmdBuffer[2] = (byte)0x00;
						CmdBuffer[3] = (byte)0x00;
						Send_CMD_Status = 1;				    
						break;
					default:
						break;
				}
				return false;
			}
		});
		
		TurnLeft.setOnTouchListener(new View.OnTouchListener() 
		{
			public boolean onTouch(View v, MotionEvent event) 
			{
				int action = event.getAction();
				switch(action)
				{
					case MotionEvent.ACTION_DOWN:
				    	CmdBuffer[1] = (byte)0x00;
						CmdBuffer[2] = (byte)0x03;
						CmdBuffer[3] = (byte)0x00;
						Send_CMD_Status = -1;							    
				    	break;
					case MotionEvent.ACTION_UP:
						CmdBuffer[1] = (byte)0x00;
						CmdBuffer[2] = (byte)0x00;
						CmdBuffer[3] = (byte)0x00;
						Send_CMD_Status = 1;				    
						break;
					default:
						break;
				}
				return false;
			}
		});
		
		TurnRight.setOnTouchListener(new View.OnTouchListener() 
		{
			public boolean onTouch(View v, MotionEvent event) 
			{
				int action = event.getAction();
				switch(action)
				{
					case MotionEvent.ACTION_DOWN:
				    	CmdBuffer[1] = (byte)0x00;
						CmdBuffer[2] = (byte)0x04;
						CmdBuffer[3] = (byte)0x00;
						Send_CMD_Status = -1;							    
				    	break;
					case MotionEvent.ACTION_UP:
						CmdBuffer[1] = (byte)0x00;
						CmdBuffer[2] = (byte)0x00;
						CmdBuffer[3] = (byte)0x00;
						Send_CMD_Status = 1;				    
						break;
					default:
						break;
				}
				return false;
			}
		});
		
		Light.setOnTouchListener(new View.OnTouchListener() 
		{
			public boolean onTouch(View v, MotionEvent event) 
			{
				int action = event.getAction();
				switch(action)
				{
					case MotionEvent.ACTION_DOWN:
				    	CmdBuffer[1] = (byte)0x02;
						if(!Is_Lighted)
						{
							CmdBuffer[2] = (byte)0x01;
							Is_Lighted = true;
							((Button)v).setTextColor(Color.WHITE);
							
						}
						else 
						{
							CmdBuffer[2] = (byte)0x00;
							Is_Lighted = false;
							((Button)v).setTextColor(Color.BLACK);
					
						}
						CmdBuffer[3] = (byte)0x00;
						Send_CMD_Status = 1;							    
				    	break;
					case MotionEvent.ACTION_UP:	
						break;
					default:
						break;
				}
				return false;
			}
		});

		
		CAM_Up.setOnTouchListener(new View.OnTouchListener() 
		{
			public boolean onTouch(View v, MotionEvent event) 
			{
				int action = event.getAction();
				switch(action)
				{
					case MotionEvent.ACTION_DOWN:
						CmdBuffer[1] = (byte)0x01;
				    	CmdBuffer[2] = (byte)0x02;			    	
				    	if (Cam_UpDown < 0xA0 - step && Cam_UpDown > 0x65) Cam_UpDown += step;
						CmdBuffer[3] = (byte)Cam_UpDown;
						Send_CMD_Status = 1;
				    	break;
					case MotionEvent.ACTION_UP:			    
						break;
					default:
						break;
				}
				return false;
			}
		});
		
		CAM_Down.setOnTouchListener(new View.OnTouchListener() 
		{
			public boolean onTouch(View v, MotionEvent event) 
			{
				int action = event.getAction();
				switch(action)
				{
					case MotionEvent.ACTION_DOWN:
						CmdBuffer[1] = (byte)0x01;
				    	CmdBuffer[2] = (byte)0x02;
				    	if (Cam_UpDown < 0xA0 && Cam_UpDown > 0x65 + step) Cam_UpDown -= step;
						CmdBuffer[3] = (byte)Cam_UpDown;
						Send_CMD_Status = 1;
				    	break;
					case MotionEvent.ACTION_UP:			    
						break;
					default:
						break;
				}
				return false;
			}
		});
		
		CAM_Left.setOnTouchListener(new View.OnTouchListener() 
		{
			public boolean onTouch(View v, MotionEvent event) 
			{
				int action = event.getAction();
				switch(action)
				{
					case MotionEvent.ACTION_DOWN:
						CmdBuffer[1] = (byte)0x01;
				    	CmdBuffer[2] = (byte)0x01;
				    	if (Cam_LeftRight < 0xB0 - step && Cam_LeftRight > 0x10) Cam_LeftRight += step;
						CmdBuffer[3] = (byte)Cam_LeftRight;
						Send_CMD_Status = 1;
				    	break;
					case MotionEvent.ACTION_UP:			    
						break;
					default:
						break;
				}
				return false;
			}
		});
		
		CAM_Right.setOnTouchListener(new View.OnTouchListener() 
		{
			public boolean onTouch(View v, MotionEvent event) 
			{
				int action = event.getAction();
				switch(action)
				{
					case MotionEvent.ACTION_DOWN:
						CmdBuffer[1] = (byte)0x01;
				    	CmdBuffer[2] = (byte)0x01;
				    	if (Cam_LeftRight < 0xB0 && Cam_LeftRight > 0x10 + step) Cam_LeftRight -= step;
						CmdBuffer[3] = (byte)Cam_LeftRight;
						Send_CMD_Status = 1;
				    	break;
					case MotionEvent.ACTION_UP:			    
						break;
					default:
						break;
				}
				return false;
			}
		});
		
		CAM_Reset.setOnTouchListener(new View.OnTouchListener() 
		{
			public boolean onTouch(View v, MotionEvent event) 
			{
				int action = event.getAction();
				switch(action)
				{
					case MotionEvent.ACTION_DOWN:
						Send_CMD_Status = 2;			    	
				    	Cam_Reset_Status = 2;	
				    	break;
					case MotionEvent.ACTION_UP:	
						break;
					default:
						break;
				}
				return false;
			}
		});
				
	}

    private byte[] CmdBuffer = {(byte) 0xFF,(byte)0x00,(byte)0x00,(byte)0x00,(byte) 0xFF};
	private Runnable mRunnable	= new Runnable() 
	{
		public void run()
		{
			while(true)
			{
				if(Send_CMD_Status==0) 
				{
					try 
					{
						Thread.sleep(50);
					} catch (InterruptedException e) 
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					continue;
				}
				if(Send_CMD_Status>0) Send_CMD_Status--;
				
				if(Cam_Reset_Status==2)
				{
					Cam_Reset_Status = 1;
					
					CmdBuffer[1] = (byte)0x01;
					CmdBuffer[2] = (byte)0x02;
					Cam_UpDown = 0x7B; 
					CmdBuffer[3] = (byte)Cam_UpDown;
				}
				else if(Cam_Reset_Status==1)
				{
					Cam_Reset_Status = 0;
					
					CmdBuffer[1] = (byte)0x01;
					CmdBuffer[2] = (byte)0x01;
					Cam_LeftRight = 0x5A; 
					CmdBuffer[3] = (byte)Cam_LeftRight;
					
				}
				else 
				{
					Cam_Reset_Status = 0;
				}

				
				try 
				{
					//���ӷ�����
					mSocketClient = new Socket(CtrlIp,Integer.parseInt(CtrlPort));
					//ȡ�����롢�����
					//mBufferedReaderClient = new BufferedReader(new InputStreamReader(mSocketClient.getInputStream()));
					//mPrintWriterClient = new PrintWriter(mSocketClient.getOutputStream(), true);
					mSocketClient.getOutputStream().write(CmdBuffer);
					//mSocketClient.getOutputStream().write(CmdBuffer);
					mSocketClient.close();
					
					Thread.sleep(100);
				}	
				catch (Exception ex) 
				{
					mSocketClient = null;
				}
				
				
				
			} 
			
		}
	};
	
		
	public void onDestroy() 
	{
		super.onDestroy();
	
		try 
		{
			if(mSocketClient!=null)
			{
				mSocketClient.close();
				mSocketClient = null;
			}
	
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		mThreadClient.interrupt();
	}
	
	private long exitTime = 0;
	@Override  
    public boolean onKeyDown(int keyCode, KeyEvent event)   
    {  
		 if(keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN)  
		 {  
		           
		         if((System.currentTimeMillis()-exitTime) > 2500)  //System.currentTimeMillis()���ۺ�ʱ���ã��϶�����2500   
				 {  
					 Toast.makeText(getApplicationContext(), "�ٰ�һ���˳�����",Toast.LENGTH_SHORT).show();                                  
		        	 exitTime = System.currentTimeMillis();  
				 }  
		         else  
		         {  
		             finish();  
		             System.exit(0);  
		         }  
		                   
		         return true;  
		 }  
		 return super.onKeyDown(keyCode, event);  
    }  

}


